public class Main {
    public static void main(String[] args) {
        TV tv = new TV();
        AC ac = new AC();
        Fan fan = new Fan();
        Light light = new Light();

        HomeTheaterFacade homeTheater = new HomeTheaterFacade(tv, ac, fan, light);
        String result = homeTheater.watchMovie();
        System.out.println(result);
    }
}
