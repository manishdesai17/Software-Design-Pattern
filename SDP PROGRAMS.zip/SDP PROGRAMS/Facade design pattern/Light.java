class Light {
    String off() {
        return "Lights are OFF";
    }
}
