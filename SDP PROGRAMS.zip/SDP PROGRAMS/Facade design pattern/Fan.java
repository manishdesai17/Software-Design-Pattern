class Fan {
    String on() {
        return "Fan is ON";
    }
}
