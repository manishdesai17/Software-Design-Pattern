class AC {
    String on() {
        return "AC is ON";
    }
}
