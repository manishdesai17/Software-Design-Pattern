class HomeTheaterFacade {
    private TV tv;
    private AC ac;
    private Fan fan;
    private Light light;

    public HomeTheaterFacade(TV tv, AC ac, Fan fan, Light light) {
        this.tv = tv;
        this.ac = ac;
        this.fan = fan;
        this.light = light;
    }

    public String watchMovie() {
        StringBuilder sb = new StringBuilder();
        sb.append("Preparing to watch a movie...\n");
        sb.append(ac.on()).append("\n");
        sb.append(fan.on()).append("\n");
        sb.append(light.off()).append("\n");
        sb.append(tv.on()).append("\n");
        return sb.toString();
    }
}
