class TV {
    String on() {
        return "TV is ON";
    }
}
