public interface main_course{
    public String Create_Main_course();
}