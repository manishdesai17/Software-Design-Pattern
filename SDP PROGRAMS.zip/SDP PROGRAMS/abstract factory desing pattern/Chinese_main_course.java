public class Chinese_main_course implements main_course{
    public String Create_Main_course()
    {
     return "create Chinese main course dish";
    }
 }
