package Singlt;

public class singletonClient {
    public static void main(String[] args) {
        DbConnection db = DbConnection.getInstance();
        DbConnection db1 = DbConnection.getInstance();
        try {
            System.out.println(db.hashCode());
            System.out.println(db.connect());
            System.out.println(db1.hashCode());
            System.out.println(db1.connect());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
