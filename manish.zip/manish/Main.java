import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;

public class Main {
    public static void main(String[] args) {
        try {
            InputStream ins = new FileInputStream("text.txt");
            LoginInputstreamdemo s = new LoginInputstreamdemo(ins);
            int data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            data = s.read();
            s.close();
            System.out.println("read char=" + s.countcharacter());
            System.out.println("read word=" + s.countword());
            System.out.println("read line=" + s.countline());


            FileWriter os = new FileWriter("text.txt", true);
            outputStreamdemo o = new outputStreamdemo(os);
            o.write("Manish desai ");
            System.out.println("write char=" + o.writeByteCount());
            System.out.println("write word="+o.writeWordCount());
            o.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
