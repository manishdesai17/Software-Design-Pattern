import java.io.FileWriter;
import java.io.IOException;

public class outputStreamDecorator {

    public FileWriter ins;

    public outputStreamDecorator(FileWriter ins) {
        this.ins = ins;
    }

    public void write(String data) throws IOException {
        ins.write(data);
    }

    public void close() throws IOException {
        ins.close();
    }
}