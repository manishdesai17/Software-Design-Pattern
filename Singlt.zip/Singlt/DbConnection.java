package Singlt;

import java.sql.*;

public class DbConnection {
    private static DbConnection obj;
    private Connection con;

    private DbConnection() {
    }

    public Connection connect() throws Exception {
        if (con == null) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mca1", "root", "jalasakaro1234");
        }
        return con;
    }

    public static DbConnection getInstance() {
        if (obj == null) {
            obj = new DbConnection();
        }
        return obj;
    }
}
